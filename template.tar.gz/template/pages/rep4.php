<!DOCTYPE html>
<?php
require_once('init.php');
require_once('sessionInit.php');

?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>File Automation</title>
	<script src="Chart.js"></script>
		<script src="Chart.Core.js"></script>
		<script src="Chart.Doughnut.js"></script>
    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
  <?php
		require_once('navigation.php');
		?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
						<!-- START HERE 
						<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Number of files</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="odd gradeX">
                                            <td>Projects(Final year)</td>
                                            <td><?php db_select('8_sem_project','COUNT(*)');
											
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
                                        <tr class="even gradeC">
                                            <td>Examination</td>
                                            <td><?php db_select('examination','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
										<tr class="odd gradeX">
                                            <td>Admission	</td>
                                            <td><?php db_select('admission','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
                                        <tr class="even gradeC">
                                            <td>Conferences</td>
                                            <td><?php db_select('conferece','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
										<tr class="odd gradeX">
                                            <td>Counsellor's</td>
                                            <td><?php db_select('counsellor','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
                                        <tr class="even gradeC">
                                            <td>Inventory</td>
                                            <td><?php db_select('inventory','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
										<tr class="odd gradeX">
                                            <td>MOUS</td>
                                            <td><?php db_select('mou','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
                                        <tr class="even gradeC">
                                            <td>Placement</td>
                                            <td><?php db_select('placement','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
										<tr class="odd gradeX">
                                            <td>Publication</td>
                                            <td><?php db_select('publication','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
                                       <tr class="odd gradeX">
                                            <td>R&D</td>
                                            <td><?php db_select('rnd','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
									</tbody>
						</table>
						
						END HERE -->
					<div id="canvas-holder">
			<canvas id="chart-area" width="500" height="500"/>
		</div>

						<!-- END HERE -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

	
	
	<script>

		var doughnutData = [
				{
					value: <?php db_select('8_sem_project','COUNT(*)');
											
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,
					label: "project"
				},
				{
					value: <?php db_select('examination','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,
					label: "examination"
				},
				{
					value: <?php db_select('admission','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,
					label: "admission"
				},
				{
					value: <?php db_select('conferece','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,
					label: "conferece"
				},
				{
					value: <?php db_select('inventory','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,
					label: "inventory"
				},{
					value: <?php db_select('counsellor','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,
					label: "counsellor"
				},{
					value: <?php db_select('mou','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,
					label: "mou"
				},{
					value: <?php db_select('placement','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,
					label: "placement"
				},{
					value: <?php db_select('publication','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,
					label: "publication"
				}

			];

			window.onload = function(){
				var ctx = document.getElementById("chart-area").getContext("2d");
				window.myDoughnut = new Chart(ctx).Doughnut(doughnutData, {responsive : true});
			};



	</script>
</body>

</html>
