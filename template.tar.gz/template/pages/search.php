<!DOCTYPE html>
<?php
require_once('init.php');
require_once('sessionInit.php');
$table_name = "8_sem_project";//,admission,conferece,counsellor,examination,inventory,mou,placement,publication,rnd,teacher";
$what = "project_name,file_link";
$where_clause = "8_sem_project.project_name LIKE '".$_POST[searchName]."%'";
//SELECT Customers.City,Categories.Description FROM Categories,Customers where Customers.City LIKE 's%' AND Categories.Description LIKE 's%'
db_select($table_name,$what, $where_clause);
$Seacrh=array();
if(sizeof($GLOBALS['rows'])>1)
	$Search['8_sem_project'] =$GLOBALS['rows'];

/*admission*/
$table_name = "admission";//,admission,conferece,counsellor,examination,inventory,mou,placement,publication,rnd,teacher";
$what = "admission.USN,file_link";
$where_clause = "admission.USN LIKE '".$_POST[searchName]."%'";
db_select($table_name,$what, $where_clause);
$Seacrh=array();
if(sizeof($GLOBALS['rows'])>1)
	$Search['admission'] =$GLOBALS['rows']; 
/*conferece*/
$table_name = "conferece";//,admission,conferece,counsellor,examination,inventory,mou,placement,publication,rnd,teacher";
$what = "topic,file_link";
$where_clause = "conferece.topic LIKE '".$_POST[searchName]."%'";
db_select($table_name,$what, $where_clause);
$Seacrh=array();
if(sizeof($GLOBALS['rows'])>1)
	$Search['conferece'] =$GLOBALS['rows']; 
//print_r($Search);
/*counsellor*/
$table_name = "counsellor";//,admission,conferece,counsellor,examination,inventory,mou,placement,publication,rnd,teacher";
$what = "file_name,file_link";
$where_clause = "counsellor.file_name LIKE '".$_POST[searchName]."%'";
db_select($table_name,$what, $where_clause);
$Seacrh=array();
if(sizeof($GLOBALS['rows'])>1)
	$Search['counsellor'] =$GLOBALS['rows']; 
/*examination*/
$table_name = "examination";//,admission,conferece,counsellor,examination,inventory,mou,placement,publication,rnd,teacher";
$what = "course_ID,file_link";
$where_clause = "examination.course_ID LIKE '".$_POST[searchName]."%'";
db_select($table_name,$what, $where_clause);
$Seacrh=array();
if(sizeof($GLOBALS['rows'])>1)
	$Search['examination'] =$GLOBALS['rows']; 
/*inventory*/
$table_name = "inventory";//,admission,conferece,counsellor,examination,inventory,mou,placement,publication,rnd,teacher";
$what = "type,file_link";
$where_clause = "inventory.type LIKE '".$_POST[searchName]."%'";
db_select($table_name,$what, $where_clause);
$Seacrh=array();
if(sizeof($GLOBALS['rows'])>1)
	$Search['inventory'] =$GLOBALS['rows']; 
/*mou*/
$table_name = "mou";//,admission,conferece,counsellor,examination,inventory,mou,placement,publication,rnd,teacher";
$what = "topic,file_link";
$where_clause = "mou.topic LIKE '".$_POST[searchName]."%'";
db_select($table_name,$what, $where_clause);
$Seacrh=array();
if(sizeof($GLOBALS['rows'])>1)
	$Search['mou'] =$GLOBALS['rows']; 
/*placement*/
$table_name = "placement";//,admission,conferece,counsellor,examination,inventory,mou,placement,publication,rnd,teacher";
$what = "USN,file_link";
$where_clause = "placement.USN LIKE '".$_POST[searchName]."%'";
db_select($table_name,$what, $where_clause);
$Seacrh=array();
if(sizeof($GLOBALS['rows'])>1)
	$Search['placement'] =$GLOBALS['rows']; 
/*publication*/
$table_name = "publication";//,admission,conferece,counsellor,examination,inventory,mou,placement,publication,rnd,teacher";
$what = "publication_name,file_link";
$where_clause = "publication.publication_name LIKE '".$_POST[searchName]."%'";
db_select($table_name,$what, $where_clause);
$Seacrh=array();
if(sizeof($GLOBALS['rows'])>1)
	$Search['publication'] =$GLOBALS['rows'];
/*rnd*/
$table_name = "rnd";//,admission,conferece,counsellor,examination,inventory,mou,placement,publication,rnd,teacher";
$what = "project_name,file_link";
$where_clause = "rnd.project_name LIKE '".$_POST[searchName]."%'";
db_select($table_name,$what, $where_clause);
$Seacrh=array();
if(sizeof($GLOBALS['rows'])>1)
	$Search['rnd'] =$GLOBALS['rows']; 

//print_r($Search);
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>File Automation</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim,Respond.js IE8 support of HTML5 elements,media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
  <?php
		require_once('navigation.php');
		?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
						<!-- START HERE -->
						<div class="list-group">
					<?php
					$tables=array("8_sem_project" => "project_name","admission"=>"USN","conferece"=>"topic","counsellor"=> "file_name","examination" => "course_ID","inventory" => "type","mou" => "topic","placement" => "USN","publication" => "publication_name","rnd"=> "project_name","teacher");
					$keys = array_keys($tables);
					//$j=0;
					for($j=0;$j<sizeof($keys);$j++)
						{
						if(isset($Search[$keys[$j]]))
						{
							$c = sizeof($Search[$keys[$j]])-1;
							for($i=0;$i<$c;$i++)
							{
								echo '	
							  <a href="'.'uploads/'.$Search[$keys[$j]][$i]['file_link'].'" class="list-group-item">
								<h4 class="list-group-item-heading">'.$keys[$j].' '.$tables[$keys[$j]].' '.$Search[$keys[$j]][$i][$tables[$keys[$j]]].'</h4>
							  </a>
							';
							}
						}
					}
					?>
						</div>

						<!-- END HERE -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
