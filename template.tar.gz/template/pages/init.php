<?php
//header("Location: ../db/connect.php");
	//error_reporting(0);
	require_once('db/connect.php');
   require_once('db/dbTransactions.php');

    ?>
