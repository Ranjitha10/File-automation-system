<!DOCTYPE html>
<?php
require_once('init.php');
require_once('sessionInit.php');

?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>File Automation</title>
	<script src="Chart.js"></script>
    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
  <?php
		require_once('navigation.php');
		?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
						<!-- START HERE 
						<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Number of files</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="odd gradeX">
                                            <td>Projects(Final year)</td>
                                            <td><?php db_select('8_sem_project','COUNT(*)');
											
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
                                        <tr class="even gradeC">
                                            <td>Examination</td>
                                            <td><?php db_select('examination','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
										<tr class="odd gradeX">
                                            <td>Admission	</td>
                                            <td><?php db_select('admission','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
                                        <tr class="even gradeC">
                                            <td>Conferences</td>
                                            <td><?php db_select('conferece','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
										<tr class="odd gradeX">
                                            <td>Counsellor's</td>
                                            <td><?php db_select('counsellor','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
                                        <tr class="even gradeC">
                                            <td>Inventory</td>
                                            <td><?php db_select('inventory','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
										<tr class="odd gradeX">
                                            <td>MOUS</td>
                                            <td><?php db_select('mou','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
                                        <tr class="even gradeC">
                                            <td>Placement</td>
                                            <td><?php db_select('placement','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
										<tr class="odd gradeX">
                                            <td>Publication</td>
                                            <td><?php db_select('publication','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
                                       <tr class="odd gradeX">
                                            <td>R&D</td>
                                            <td><?php db_select('rnd','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?></td>
                                        </tr>
									</tbody>
						</table>
						
						END HERE -->
					<div style="width: 50%">
						<canvas id="canvas" height="1024" width="900"></canvas>
					</div>	
						<!-- END HERE -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
<script>
	var randomScalingFactor = function(){ return Math.round(Math.random()*100)};

	var barChartData = {
		labels : ["* Semester Project","Examination","Admission","Conferece","Counsellor","Inventory","MOU","Placement","Publication","R&D"],
		datasets : [
			{
				fillColor : "rgba(151,187,205,0.5)",
				strokeColor : "rgba(220,220,220,0.8)",
				highlightFill: "rgba(220,220,220,0.75)",
				highlightStroke: "rgba(220,220,220,1)",
				data : [<?php db_select('8_sem_project','COUNT(*)');
											
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,<?php db_select('examination','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,<?php db_select('admission','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,<?php db_select('conferece','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,<?php db_select('counsellor','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,<?php db_select('inventory','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,<?php db_select('mou','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,<?php db_select('placement','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,<?php db_select('publication','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>,<?php db_select('rnd','COUNT(*)');
	echo $GLOBALS['rows'][0]['COUNT(*)'];?>]
			}
		]

	}
	window.onload = function(){
		var ctx = document.getElementById("canvas").getContext("2d");
		window.myBar = new Chart(ctx).Bar(barChartData, {
			responsive : true
		});
	}

	</script>
</body>

</html>
