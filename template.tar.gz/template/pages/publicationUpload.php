<!DOCTYPE html>
<?php
require_once('init.php');
require_once('sessionInit.php');
if(isset($_POST['submit']))
{   
    $what = 'f_ID_no';
    db_select('faculty',$what,"where email='".$_SESSION['Email']."'");    
    require_once 'functions/upload.php';
    //$path = "uploads/";
    //move_uploaded_file($_FILES["file"]["tmp_name"], $path.$_FILES['file']['name'] );
   $formData = array(
					'Uploadedby' => $_SESSION['f_ID_no'],
                    'publication_name' => $_POST['publication_name'],
                    'author' =>$_POST['author'],
					'publisher' =>$_POST['publisher'],
					'issue_date' =>$_POST['issue_date'],
					'ISSN' =>$_POST['ISSN'],
                    'file_link' => $_FILES['file_link']['name']
                    );
                db_insert('publication',$formData);
 echo '
     <div class="alert alert-success">
                               File has been Uploaded
                            </div>
     ';    
                
}
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>File Automation</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
  <?php
		require_once('navigation.php');
		?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
						<!-- START HERE -->
							  <div class="col-lg-12">
					<div class="panel panel-info">

					<div class="panel-heading">
                            Upload Publication Document                            
                        </div>
					 <div class="panel-body">

                        <div class="form-group">
                                    <form method="post" enctype="multipart/form-data">
                                        <input class="form-control" required placeholder = "Enter publication name" name="publication_name" pattern="[a-zA-Z0-9]+"
>    </br>             
                                        <input class="form-control" required placeholder = "Enter author" name="author" pattern="[a-zA-Z]+"
>    </br>             
                                        <input class="form-control" required placeholder = "Enter publisher" name="publisher" pattern="[a-zA-Z0-9]+"
>    </br>             
                                        <input class="form-control" required placeholder = "Enter issue date" name="issue_date" type="date">     </br>
										<input class="form-control" required placeholder = "Enter ISSN" name="ISSN" pattern="[0-9]+"
>    </br>										
                                        <input type="file" name="file_link" size="50" />	</br>
										<button type="submit" class="btn btn-primary" name="submit">Submit</button>
                                        
                                    </form>
                            </div>
							</div></div>
                    </div>

						
						
						<!-- END HERE -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
