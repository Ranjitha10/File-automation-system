<?php
copy("test.txt","target.txt");

?>