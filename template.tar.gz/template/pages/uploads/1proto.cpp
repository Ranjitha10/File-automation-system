#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <string>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    int r,c,i;
    size_t check,tmpcheck;
    cin>>r>>c;
    string data[r];
    for(i=0;i<r;i++)
    {
        cin>>data[i];
    }
cin>>rp>>cp;
    string pattern[rp];
    for(i=0;i<rp;i++)
    {
        cin>>pattern[i];
    }
    int pn=0,tmp;
    for(i=0;i<r;i++)
    {
        check=data[i].find(pattern[pn]);
        tmpcheck=check;
        tmp=i;
        if(check!= std::string::npos)
        {
            tmp++;
            for(int k=1;k<rp;k++)
            {
                tmpcheck = data[tmp].find(pattern[pn],check+1,cp) ;

            }
        }
    }
    return 0;
}
