
<?php
if(isset($_POST['ok']))
{
    $path = "uploads/";
    echo $_FILES["file"]["tmp_name"];
    echo '<br>';
    echo $_FILES['file']['name'];
  move_uploaded_file($_FILES["file"]["tmp_name"], $path.$_FILES['file']['name'] );
}
?>

<html>
<head>
<title>File Uploading Form</title>
</head>
<body>
<h3>File Upload:</h3>
Select a file to upload: <br />
<form action="" method="post"
                        enctype="multipart/form-data">
<input type="file" name="file" size="50" />
<br />
<input type="submit" value="Upload File" name="ok" />
</form>
</body>
</html>