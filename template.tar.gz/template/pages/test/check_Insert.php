<?php

	require_once('connect.php');
   	require_once('dbTransactions.php');
   	if(isset($_POST['Name']))
	{		
		 $formData = array(
	        'Name' => $_POST['Name'],
	        'USN' => $_POST['USN'],
	        'Gender' => $_POST['Gender'],
	        'Year_of_joining' =>$_POST['Year_of_joining'],
	        'Department' => $_POST['Department'],
	        'Sem' => $_POST['Sem'],
	        'Email' => $_POST['Email'],
	        'Mobile' => $_POST['Mobile']
	        );
	     db_insert('student',$formData);
	     echo 'inserted';
    }

?>
<form method = "post" action = "">
	Name:<input type = "text" name = "Name" >
</input>
<br>
USN:<input type = "text" name = "USN">
</input>
<br>
Gender:<input type = "text" name = "Gender">
</input>
<br>
Year_of_joining
<input type = "text" name = "Year_of_joining">
</input>
<br>
Department:
<input type = "text" name = "Department">
</input>
<br>
Sem<input type = "text" name = "Sem">
</input>
<br>
Email<input type = "text" name = "Email">
</input>
<br>
Mobile:
<input type = "text" name = "Mobile">
</input>
<br>
<INPUT type="submit">
</form>