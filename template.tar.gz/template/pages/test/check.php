<?php
    require_once('connect.php');
   require_once('insert.php');
    /*
    $x = array(
        'id' => 4223,
        'user' => 'hello'
        );
     db_insert('test',$x);
    db_delete('test','where id = 2')
    db_update('test', $x, "WHERE id = 423");
        $what = 'user';
        db_select('test',$what,"where id=43");
        print_r($GLOBALS['rows']);
        echo $GLOBALS['rows'][0]['user'];
    */
//Demo Login
if(isset($_POST['id']))
{
   $what = 'id';
   db_select('test',$what,"where id=".$_POST['id']);
   print_r($GLOBALS['rows']);
   if(sizeof($GLOBALS['rows'])>0)
   {
        echo 'valid';
   }
   else
   {
        echo 'invalid';
   }
}
?>
        <form method="post">
        <input name="id" type="text"></input>
        <input type="submit" value="submit">
        </form>