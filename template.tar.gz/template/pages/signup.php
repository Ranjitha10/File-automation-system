<!DOCTYPE html>
<?php

	require_once('init.php');
  

   	if(isset($_POST['name']))
	{		
		
	     if($_POST['Category'] == 'Student')
            {
                 $formData = array(
                    'name' => $_POST['name'],
                    'USN' => $_POST['USN'],
                    'gender' => $_POST['gender'],
                    'pass' =>$_POST['pass'],
                    'dept' => $_POST['dept'],
                    'dob' => $_POST['dob'],
                    'year' => $_POST['year'], 
                  'email'=> $_POST['email']
          
                    );
                db_insert('student',$formData);
                echo '<div class="panel-body">
                            <div class="alert alert-success">
                                Your account is Created. <a href="login.php">Login</a>
                            </div>
                        
                        </div>';
            }
            else
            {
                echo "Err";
            }
        if($_POST['Category'] == 'Faculty')
            {
                 $formData = array(
                    'name' => $_POST['name'],
                    'f_ID_no' => $_POST['f_ID_no'],
                    'gender' => $_POST['gender'],
                    'pass' =>$_POST['pass'],
                    'dept' => $_POST['dept'],
                    'dob' => $_POST['dob'],
                    'email'=> $_POST['email']
                    );
                db_insert('faculty',$formData);
                echo '<div class="panel-body">
                            <div class="alert alert-success">
                                Your account is Created. <a href="login.php">Login</a>
                            </div>
                        
                        </div>';
            }    
	     
    }

?>
<html lang="en">

<head>
    <script type="https://bootswatch.com/yeti/bootstrap.min.css"></script>
    <script type="https://bootswatch.com/yeti/bootstrap.css"></script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>File Automation</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Sign Up</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" method = "post" action = "" id="Signup">
                            <fieldset>
								<div class="form-group">                                
                                <select id="Category" name= "Category" >
								<option  value="Admin">Select Role </option>
                                  <option  value="Student">Student</option>
                                  <option  value="Faculty">Faculty</option>                                  
                                </select>
                                </div>
                                <div id="Student" class="category">
								<div class="form-group">
                                    <input class="form-control" placeholder="Enter Name" name="name" type="name" autofocus >
                                </div>
								
								<div class="form-group">
                                    <input class="form-control" placeholder="Enter USN" name="USN" type="text" >
                                </div>
								
								<div class="form-group">
                                    <input class="form-control" placeholder="Enter Gender" name="gender" type="text" >
                                </div>
								
								<div class="form-group">
                                    <input class="form-control" placeholder="Enter Year of Joining" name="year" type="text" >
                                </div>
								
								<div class="form-group">
                                    <input class="form-control" placeholder="Enter Department" name="dept" type="text" >
                                </div>
								
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Semester" name="sem" type="text" >
                                </div>												
								<div class="form-group">
                                    <input class="form-control" placeholder="Enter Email" name="email" type="email" >
                                </div>
								<div class="form-group">
                                    <input class="form-control" placeholder="Enter Email" name="dob" type="date" >
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Password" name="pass" type="password" >
                                </div>
                                <!-- Change this to a button or input when using this as a form 
								<a href="index.html" class="btn btn-lg btn-success btn-block">Login</a>
								-->
								<input type="submit">
                            </div>
							
                                <div id="Faculty" class="category">
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Name" name="name" type="name" autofocus >
                                </div>
                                
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Faculty Id" name="f_ID_no" type="text" >
                                </div>
                                
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Gender" name="gender" type="text" >
                                </div>
                                
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Password" name="pass" type="text" >
                                </div>
                                
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Department" name="dept" type="text" >
                                </div>
                                
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Date of Birth" name="dob" type="date" >
                                </div>                                              
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Email" name="email" type="email" >
                                </div>
                                <!-- Change this to a button or input when using this as a form 
                                <a href="index.html" class="btn btn-lg btn-success btn-block">Login</a>
								
                                -->
								<INPUT type="submit">

                            </div>



                                
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    

    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
<script type="text/javascript">
		var x=$('#Faculty').remove();
		var y=$('#Student').remove();			

  $( "#Category" ).change(function() {
		if($(this).val()=="Student")
		{
			$('#Faculty').remove();
			$( "#Signup" ).append(y);
		}
		if($(this).val()=="Faculty")
		{
			$('#Student').remove();
			$( "#Signup" ).append(x);			
		}
		//$( "#Signup" ).append(x);
	});
    </script>

</body>

</html>
