<?php
$db=array(
	"host"=>"localhost",
	"username" => "root",
	"password"=>"root",
	"db_name"=>"fileautomation"
		);
 $GLOBALS['con'] = mysqli_connect($db['host'],$db['username'],$db['password'],$db['db_name']);

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>

