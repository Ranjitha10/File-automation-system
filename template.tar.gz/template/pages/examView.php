<!DOCTYPE html>
<?php
require_once('init.php');
require_once('sessionInit.php');

?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>File Automation</title>
  <script src="../bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	
	<script type="text/javascript" language="javascript" src="../pages/dataTables/media/js/jquery.dataTables.js"></script>
	    <script src="../bower_components/DataTables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
	  <!-- DataTables CSS -->
    <link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
<!--
	<script type="text/javascript" language="javascript" src="/pages/dataTables/resources/syntax/shCore.js"></script>
	<script type="text/javascript" language="javascript" src="../resources/demo.js"></script>
-->	
	

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
  <?php
		require_once('navigation.php');
		?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
						<!-- START HERE -->
						<div class="panel panel-info">
						  <div class="panel-heading">
							<h3 class="panel-title">Select an Operation first to perform an Action on element</h3>
						  </div>						  
						</div>
						<?php
						$what = '*';
						db_select('examination',$what);
						$count = sizeof($GLOBALS['rows']) - 2;
						echo '<table class="table table-striped table-hover " id="example">
							   <thead>
								  <tr>
									 
									 <th>Course ID</th>
									 <th>Faculty ID</th>
									 <th>Type</th>
									 <th>Date</th>
									 <th>Semester</th>
									 <th>Programme</th>
									 <th>File</th>
									 <th>Year</th>
								  </tr>
							   </thead>
							   <tbody>';
						while( $count >= 0 )
						{
								echo 
								'							   
								  <tr id="'.trim($GLOBALS['rows'][$count]['course_ID']).'"'." data=".$GLOBALS['rows'][$count]['date'];
								  echo '>
									 <td>';
									 echo $GLOBALS['rows'][$count]['course_ID']; 
									 echo '</td>';									
								  //echo '</tr>';

								  echo 
							'							   
								  
									 <td>';
									 echo $GLOBALS['rows'][$count]['f_ID_no']; 
									 echo '</td>';									
								  

							echo 
							'							   								  
									 <td>';
									 echo $GLOBALS['rows'][$count]['type']; 
									 echo '</td>';									
								  

							echo 
							'							   								  
									 <td>';
									 echo $GLOBALS['rows'][$count]['date']; 
									 echo '</td>';									
	

							echo 
							'							   
	
									 <td>';
									 echo $GLOBALS['rows'][$count]['semester']; 
									 echo '</td>';									
	

							echo 
							'							   
	
									 <td>';
									 echo $GLOBALS['rows'][$count]['programme']; 
									 echo '</td>';									
	

							echo 
							'							   
	
									 <td>';
									 echo '<a href="uploads/'.$GLOBALS['rows'][$count]['file_link'].'">'.$GLOBALS['rows'][$count]['file_link'].'</a>'; 
									 echo '</td>';									
	

							echo 
							'							   
	
									 <td>';
									 echo $GLOBALS['rows'][$count]['year']; 
									 echo '</td>
									 </tr>';									
	
	
						$count--;
						}
						echo '</tbody>
							</table>';
						?>
						
					<ul class="nav nav-pills">
					  <li>
					<button  class="btn btn-danger" onclick="deleteRow()">Delete</a>
						</li>
						<li>
					<button  class="btn btn-primary" onclick="copyRow()">Copy</a>
						
						</li>
						<li>
					<button  class="btn btn-info" onclick="renameRow()">Rename</a>
						
						</li>
					</ul>
						<!-- END HERE -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
  

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
<script>
$(document).ready(function() {
        $('#example').DataTable({
                responsive: true
        });
    });
</script>
<!-- Delete javascript START-->
<script>
var x=0;
var copyState=0;
$('tr').click(function() {
	
	$(x).attr("class","active");
	x=this;
	$(this).attr("class","warning");

});

//Copy ROW
function copyRow() {
if(copyState==0)
	{
		copyState = 1;		
	}
	else
	{
		copyState=0;
	}
}
 $('tr').click(function() {
			console.log($(this).attr('id'));
			console.log($(this).attr('data'));
			if(copyState==1)
	{
		   $.get("functions/examCopy.php?date="+$(this).attr('data')+"&"+"course_ID="+$(this).attr('id').trim(),function(data,status){
            alert("The record was copied. Please refresh the page to view updated Record");
			copyState=0;
        });
	}
		  });
//Copy ROW

//DELETE ROW
var deleteState = 0;
function deleteRow() {
if(deleteState==0)
	{
		deleteState = 1;		
	}
	else
	{
		deleteState=0;
	}
}
		  $('tr').click(function() {
			console.log($(this).attr('id'));
			console.log($(this).attr('data'));
			if(deleteState==1)
	{
		   $.get("functions/examDelete.php?date="+$(this).attr('data')+"&"+"course_ID="+$(this).attr('id').trim(),function(data,status){
            alert("The record was deleted. Please refresh the page to view updated Record");
			deleteState=0;
        });
	}
		  });

		deleteState=0;
//DELETE ROW

//RENAME ROW
var renameState = 0;
function renameRow() {
if(renameState==0)
	{
		renameState = 1;		
	}
}
		  $('tr').click(function() {
			console.log($(this).attr('id'));
			console.log($(this).attr('data'));
			if(renameState==1)
		{
		   window.location.assign("functions/examRename.php?date="+$(this).attr('data')+"&"+"course_ID="+$(this).attr('id').trim());
		}
		  });

//RENAME ROW

</script>
<!-- Delete javascript END-->
</body>

</html>
