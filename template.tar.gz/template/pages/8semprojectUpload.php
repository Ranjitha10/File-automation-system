<!DOCTYPE html>
<?php
require_once('init.php');
require_once('sessionInit.php');

if(isset($_POST['submit']))
{   
    $what = 'f_ID_no';
    db_select('faculty',$what,"where email='".$_SESSION['Email']."'");    
    require_once 'functions/upload.php';
    //$path = "uploads/";
    //move_uploaded_file($_FILES["file"]["tmp_name"], $path.$_FILES['file']['name'] );
   $formData = array(
					'Uploadedby' => $_SESSION['f_ID_no'],
                    'project_name' => $_POST['project_name'],
                    'f_ID_no' => $GLOBALS['rows'][0]['f_ID_no'],
                    'USN' => $_POST['USN'],
                    'submit_date' =>$_POST['submit_date'],                   
                    'dept' => $_POST['dept'],
                    'year' => $_POST['year'], 
                    'file_link' => $_FILES['file_link']['name']
                    );
                db_insert('8_sem_project',$formData);

     echo '
     <div class="alert alert-success">
                               File has been Uploaded
                            </div>
     ';           
}
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>File Automation</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
  <?php
		require_once('navigation.php');
		?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
						<!-- START HERE -->
						<div class="col-lg-12">
					<div class="panel panel-info">

						<div class="panel-heading">
                            Upload 8th sem Project Document                            
                        </div>
						<div class="panel-body">

							<div class="form-group">
                                    <form method="post" enctype="multipart/form-data">
                                        <input class="form-control" required placeholder = "Enter Project Name" name="project_name" pattern="[a-zA-Z0-9\s]+"
>    </br> 
                                        <input class="form-control" required placeholder = "Enter USN" name="USN" pattern="[a-zA-Z0-9]+"
>                                   </br>    
										<input class="form-control" required placeholder = "Enter Date of Submission" name="submit_date" type="date">     </br>           						                              
                                        <input class="form-control" required placeholder = "Enter Year of Project" name="year"pattern="[0-9]+"
>          </br>                          
                                       <select class="form-control" name="dept">
                                                <option value="Biotechnology">Biotechnology</option>
                                                <option value="Chemical Engineering">Chemical Engineering</option>
                                                <option value="Civil Engineering">Civil Engineering</option>
												<option value="Computer Science Engineering">Computer Science Engineering</option>
                                                <option value="Electrical and Electronics Engineering">Electrical and Electronics Engineering</option>
                                                <option value="Electronics & Communication Engineering">Electronics & Communication Engineering</option>
												<option value="Industrial Engineering & Management">Industrial Engineering & Management</option>
                                                <option value="Information Science & Engineering">Information Science & Engineering</option>
                                                <option value="Electronics & Instrumentation Engineering">Electronics & Instrumentation Engineering</option>
												<option value="Mechanical Engineering">Mechanical Engineering</option>
												<option value="Telecommunication Engineering">Telecommunication Engineering</option>
                                            </select>							 </br>            
                                        <input type="file" name="file_link" size="50" /> </br>
										<button type="submit" class="btn btn-primary" name="submit">Submit</button>
                                    </form>
                            </div>
						</div>
					</div>
                    </div>
						
						
					
						<!-- END HERE -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
