-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2015 at 11:20 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fileautomation`
--

-- --------------------------------------------------------

--
-- Table structure for table `8_sem_project`
--

CREATE TABLE IF NOT EXISTS `8_sem_project` (
  `project_name` varchar(300) NOT NULL,
  `year` int(30) NOT NULL,
  `dept` char(100) NOT NULL,
  `submit_date` date NOT NULL,
  `f_ID_no` varchar(30) NOT NULL,
  `USN` varchar(30) NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`project_name`,`year`,`dept`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `8_sem_project`
--

INSERT INTO `8_sem_project` (`project_name`, `year`, `dept`, `submit_date`, `f_ID_no`, `USN`, `file_link`) VALUES
('desk', 0, '', '0000-00-00', '', '', 'check1'),
('devil', 2012, 'ise', '0000-00-00', '', '', 'check2'),
('dwell', 0, '', '0000-00-00', '', '', 'check34'),
('off', 2012, 'ise', '0000-00-00', '', '', ''),
('show', 2012, 'ise', '0000-00-00', '', '', ''),
('to', 2012, 'ise', '0000-00-00', '', '', ''),
('your', 2012, 'ise', '0000-00-00', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `name` char(100) NOT NULL,
  `a_ID_no` varchar(30) NOT NULL,
  `pass` varchar(300) NOT NULL,
  `gender` char(1) NOT NULL,
  `designation` char(100) NOT NULL,
  PRIMARY KEY (`a_ID_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE IF NOT EXISTS `admission` (
  `USN` varchar(30) NOT NULL,
  `admn_no` int(30) NOT NULL,
  `rank` int(30) NOT NULL,
  `category` char(100) NOT NULL,
  `dept` char(100) NOT NULL,
  `year` int(30) NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`USN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`USN`, `admn_no`, `rank`, `category`, `dept`, `year`, `file_link`) VALUES
('d123', 0, 0, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `conferece`
--

CREATE TABLE IF NOT EXISTS `conferece` (
  `date` date NOT NULL,
  `topic` char(100) NOT NULL,
  `organizer` char(100) NOT NULL,
  `location` char(100) NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`date`,`topic`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `counsellor`
--

CREATE TABLE IF NOT EXISTS `counsellor` (
  `f_ID_no` varchar(30) NOT NULL,
  `batch_no` varchar(30) NOT NULL,
  `USN` varchar(30) NOT NULL,
  `file_type` char(100) NOT NULL,
  `file_name` varchar(300) NOT NULL,
  `date` date NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`USN`,`file_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `counsellor`
--

INSERT INTO `counsellor` (`f_ID_no`, `batch_no`, `USN`, `file_type`, `file_name`, `date`, `file_link`) VALUES
('a43', 'b1', '1rv12is004', 'medical certificate', 'swine flu', '2015-04-13', 'CSP315_presentations.pptx');

-- --------------------------------------------------------

--
-- Table structure for table `examination`
--

CREATE TABLE IF NOT EXISTS `examination` (
  `course_ID` varchar(30) NOT NULL,
  `f_ID_no` varchar(30) NOT NULL,
  `type` char(100) NOT NULL,
  `date` date NOT NULL,
  `year` int(30) NOT NULL,
  `semester` int(30) NOT NULL,
  `programme` char(100) NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`course_ID`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `examination`
--

INSERT INTO `examination` (`course_ID`, `f_ID_no`, `type`, `date`, `year`, `semester`, `programme`, `file_link`) VALUES
('12IS11', 'a43', 'CIE', '2015-04-04', 2015, 6, 'ug', 'DSC_0278.JPG'),
('171', 'a4371', 'SEE71', '0000-00-00', 201271, 371, 'UG71', 'synopsis dbms.pdf71'),
('2', 'a43', 'cie', '2015-04-16', 2012, 2, 'ug', 'Print_Synopsis.pdf'),
('249', 'a4349', 'cie49', '0000-00-00', 201249, 249, 'ug49', 'Print_Synopsis.pdf49'),
('3', 'a43', 'CIE', '2015-04-22', 2012, 2, 'UG', 'Introduction to Analytical Writing Assessment.pdf'),
('dffs3', 'a43', 'SIE', '2015-04-26', 2015, 4, 'ug', 'dept. ppt-3.02.2015.pptx'),
('dffs354', 'a4354', 'SIE54', '0000-00-00', 325254, 254, 'UG54', 'dept. ppt-3.02.2015.pptx54');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
  `name` char(100) NOT NULL,
  `f_ID_no` varchar(30) NOT NULL,
  `gender` char(1) NOT NULL,
  `pass` varchar(250) NOT NULL,
  `dept` char(100) NOT NULL,
  `dob` date NOT NULL,
  `designation` char(100) NOT NULL,
  `joining_date` date NOT NULL,
  `email` varchar(300) NOT NULL,
  PRIMARY KEY (`f_ID_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`name`, `f_ID_no`, `gender`, `pass`, `dept`, `dob`, `designation`, `joining_date`, `email`) VALUES
('Pranay Kumar', 'a43', 'M', '123', 'ise', '2015-04-18', '', '0000-00-00', 'pranay04k@yahoo.in');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE IF NOT EXISTS `inventory` (
  `type` char(100) NOT NULL,
  `i_ID_no` varchar(30) NOT NULL,
  `dept` char(100) NOT NULL,
  `location` char(100) NOT NULL,
  `cost` int(30) NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`i_ID_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mou`
--

CREATE TABLE IF NOT EXISTS `mou` (
  `date` date NOT NULL,
  `topic` varchar(300) NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`date`,`topic`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mou`
--

INSERT INTO `mou` (`date`, `topic`, `file_link`) VALUES
('2015-04-10', 'gfdgf', 'fips-180-4.pdf'),
('2015-04-17', 'vxsx', 'sha512.c'),
('2015-04-18', 'ccsdf', '127_0_0_1.sql'),
('2015-04-23', 'fds', 'sha256-384-512.pdf'),
('2015-04-23', 'hey', 'sha256-384-512.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `placement`
--

CREATE TABLE IF NOT EXISTS `placement` (
  `year` int(30) NOT NULL,
  `USN` varchar(30) NOT NULL,
  `company` char(100) NOT NULL,
  `job_profile` char(100) NOT NULL,
  `pay` int(30) NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`USN`,`company`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `placement`
--

INSERT INTO `placement` (`year`, `USN`, `company`, `job_profile`, `pay`, `file_link`) VALUES
(2015, '1rv12is001', 'infosys', 'engineer', 25000, 'Instuctions-students.docx');

-- --------------------------------------------------------

--
-- Table structure for table `publication`
--

CREATE TABLE IF NOT EXISTS `publication` (
  `publication_name` varchar(300) NOT NULL,
  `author` char(100) NOT NULL,
  `publisher` char(100) NOT NULL,
  `issue_date` date NOT NULL,
  `ISSN` varchar(300) NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`ISSN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `publication`
--

INSERT INTO `publication` (`publication_name`, `author`, `publisher`, `issue_date`, `ISSN`, `file_link`) VALUES
('whatever', 'apurva', 'penguin', '2015-02-11', 'isbn:414156', 'CSP315_presentations.pptx');

-- --------------------------------------------------------

--
-- Table structure for table `rnd`
--

CREATE TABLE IF NOT EXISTS `rnd` (
  `project_ID` varchar(30) NOT NULL,
  `project_name` varchar(300) NOT NULL,
  `f_ID_no` varchar(30) NOT NULL,
  `USN` varchar(30) NOT NULL,
  `company` char(100) NOT NULL,
  `cost` int(30) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`project_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rnd`
--

INSERT INTO `rnd` (`project_ID`, `project_name`, `f_ID_no`, `USN`, `company`, `cost`, `start_date`, `end_date`, `file_link`) VALUES
('hfa1243', 'time machine', 'a43', '1rv12is001', 'infosys', 5000, '2015-04-08', '2015-04-11', '127_0_0_1.sql'),
('hfa12466', 'time machine 2', 'a43', '1rv12is001,1rv12is010', 'infosys', 2147483647, '2015-04-10', '2015-04-26', 'connectivity (1).php');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `name` char(100) NOT NULL,
  `USN` varchar(30) NOT NULL,
  `gender` char(1) NOT NULL,
  `pass` varchar(300) NOT NULL,
  `dept` char(100) NOT NULL,
  `dob` date NOT NULL,
  `year` int(30) NOT NULL,
  `email` varchar(300) NOT NULL,
  PRIMARY KEY (`USN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `f_ID_no` varchar(30) NOT NULL,
  `certificate_name` varchar(300) NOT NULL,
  `file_link` varchar(300) NOT NULL,
  PRIMARY KEY (`f_ID_no`,`certificate_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`f_ID_no`, `certificate_name`, `file_link`) VALUES
('a43', '10 certificate', '106544-ch04.ppt'),
('a43', '12 certificate', 'Self Study- Phase II Schedule(4th and 6th)_ for students.pdf');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
