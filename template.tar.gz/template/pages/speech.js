
window.onload=function(){
var state = 0;
      window.SpeechRecognition = window.SpeechRecognition       ||
                                 window.webkitSpeechRecognition ||
                                 null;

      if (window.SpeechRecognition === null) {
        alert("speech recognition not supported");
      } else {
        var recognizer = new window.SpeechRecognition();
      //  var transcription = document.getElementById('transcription');
        //var log = document.getElementById('log');

        // Recogniser doesn't stop listening even if the user pauses
        recognizer.continuous = true;

        // Start recognising
        recognizer.onresult = function(event) {
          inputSearch.value  = '';

          for (var i = event.resultIndex; i < event.results.length; i++) {
            if (event.results[i].isFinal) {
              inputSearch.value  = event.results[i][0].transcript ;//+ ' (Confidence: ' + event.results[i][0].confidence + ')';
            } else {
              inputSearch.value += event.results[i][0].transcript;
            }
          }
        };

        // Listen for errors
        recognizer.onerror = function(event) {
          alert('Recognition error: ' + event.message);
        };

        document.getElementById('inputSearch').addEventListener('click', function() {
          // Set if we need interim results
		  if (state == 0){
			  //recognizer.interimResults = document.querySelector('input[name="recognition-type"][value="interim"]').checked;
			  try {
				recognizer.start();
				alert('Recognition started');
			  } catch(ex) {
				alert('Recognition error: ');
			  }
			  state = 1;
		  }
		  else{
				state = 0;
			          recognizer.stop();
				alert('Recognition stopped');	
		  }
        });
		}
};
