<?php    
echo '

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>
    <script src="speech.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../bower_components/raphael/raphael-min.js"></script>
    <script src="../bower_components/morrisjs/morris.min.js"></script>
    <script src="../js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">File Automation</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                
              
                
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a href="logout.php"><button type="button" class="btn btn-info">LogOut</button></a>
                
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
							<form action="search.php" method="post">
                                <input type="text" class="form-control" placeholder="Search..." id="inputSearch" name="searchName">
                                <span class="input-group-btn">
                               <button class="btn btn-default" id="search" type="submit"> 
							<!-- 	<input type="submit" id="searchSubmit">-->
                                    <i class="fa fa-search"></i>
                                </button>
							</form>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <!--<a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>-->
							<a href="index.php"><i class="fa fa-sitemap fa-fw"></i> Examination<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="examUpload.php" class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=examination" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>
                                <li>
                                    <a href="examView.php" id="checkCategory" data="'.$_SESSION['Category'].'">View</a>
                                </li>

                            </ul>
                            <!-- /.nav-second-level -->
    
                        </li>
						<!--<li>
							<a href="index.php" class="'.$_SESSION['Category'].'"><i class="fa fa-sitemap fa-fw"></i> MOU<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li >
                                    <a href="mouUpload.php"class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="mouView.php" >View</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=mou" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>

                            </ul>

    
                        </li>-->
						<li>
                            <!--<a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>-->
							<a href="index.php"><i class="fa fa-sitemap fa-fw"></i> Placement<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="placementUpload.php"class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="placementView.php">View</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=placement" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>

                            </ul>
                            <!-- /.nav-second-level -->
    
                        </li>
						<li>
                            <!--<a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>-->
							<a href="index.php"><i class="fa fa-sitemap fa-fw"></i> Publication<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="publicationUpload.php"class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="publicationView.php">View</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=publication" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>

                            </ul>
                            <!-- /.nav-second-level -->
    
                        </li>
						<li>
                            <!--<a href="index.php" class="'.$_SESSION['Category'].'"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>-->
							<a href="index.php" class="'.$_SESSION['Category'].'"><i class="fa fa-sitemap fa-fw"></i> Research and Development<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="r&dUpload.php"class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="r&dView.php">View</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=rnd" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>

                            </ul>
                            <!-- /.nav-second-level -->
    
                        </li>
						<li>
                            <!--<a href="index.php" class="'.$_SESSION['Category'].'"> <i class="fa fa-dashboard fa-fw"></i> Dashboard</a>-->
							<a href="index.php" class="'.$_SESSION['Category'].'"><i class="fa fa-sitemap fa-fw"></i> Teacher<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="teacherUpload.php"class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="teacherView.php">View</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=teacher" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>

                            </ul>
                            <!-- /.nav-second-level -->
    
                        </li>
						<li>
                            <!--<a href="index.php" ><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>-->
							<a href="index.php" ><i class="fa fa-sitemap fa-fw"></i> Counsellor<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="counsellorUpload.php"class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="counsellorView.php">View</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=counsellor" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>

                            </ul>
                            <!-- /.nav-second-level -->
    
                        </li>
						<li>
							<a href="index.php"><i class="fa fa-sitemap fa-fw"></i> Admission<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="admissionUpload.php"class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="admissionView.php">View</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=admission" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>

                            </ul>
							
						</li>
						<li>
								<a href="index.php" class="'.$_SESSION['Category'].'"><i class="fa fa-sitemap fa-fw"></i> Inventory<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="inventoryUpload.php"class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="inventoryView.php">View</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=inventory" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>

                            </ul>
						</li>	
						<li>
                            <!--<a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>-->
							<a href="index.php"><i class="fa fa-sitemap fa-fw"></i> 8th Sem Project<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="8semprojectUpload.php"class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="8semprojectView.php">View</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=8_sem_project" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>

                            </ul>
							
						</li>
						<li>
                            <!--<a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>-->
							<a href="index.php"><i class="fa fa-sitemap fa-fw"></i> Conference <span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="conferenceUpload.php"class="'.$_SESSION['Category'].'">Upload</a>
                                </li>
                                <li>
                                    <a href="conferenceView.php">View</a>
                                </li>
                                <li>
                                    <a href="csv.php?tableName=conference" class="'.$_SESSION['Category'].'" target="_blank">Export CSV</a>
                                </li>

                            </ul>
							
							
						</li>
						<li>
							<a href=""><i class="fa fa-sitemap fa-fw"></i> Reports <span class="fa arrow"></span></a>			
							<ul class="nav nav-second-level">
                                <li>
                                    <a href="report1.php">Statistics</a>
                                </li>
                                  <li>
                                    <a href="report2.php">My Reports</a>
                                </li>
				  <li>
                                    <a href="rep3.php">Charts</a>
                                </li>
                                  <li>
                                    <a href="rep4.php">composition</a>
                                </li>
                                <li>
                                    <a href="" onclick="aboutus()">About Us</a>
                                </li>
                            </ul>
						</li>';
						if($_SESSION['Category']=='faculty')
						{
						echo '
                       <li>
							<a href="settings.php" class="'.$_SESSION['Category'].'"><i class="fa fa-gear"></i> Settings </a>			
							<p class="'.$_SESSION['Category'].'"></p>
						</li>
						';
						}
						if($_SESSION['Category']=='admin')
						{ 
						echo '
						 <li>
							<a href="admin1.php" class="'.$_SESSION['Category'].'"><i class="fa fa-gear"></i>Manage Students </a>			
							
						</li>
			
						';
						}
						echo '
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <script>
        function aboutus(){
		var xmlhttp = new XMLHttpRequest();
		var url = "aboutus.json";

		xmlhttp.onreadystatechange=function() {
		    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			//myFunction(xmlhttp.responseText);
				var x =JSON.parse(xmlhttp.responseText);
				alert(x["msg"]);
		    }
		}
		xmlhttp.open("GET", url, true);
		xmlhttp.send();
        }
        
        </script>
';
?>
