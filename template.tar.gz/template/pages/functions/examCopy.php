<?php   
require_once('../init.php');
require_once('../sessionInit.php');
//    db_select('faculty',$what,"where email='".$_SESSION['Email']."'");    
$what='*';
db_select('examination',$what,"where date='".$_GET['date']."'"." and course_ID='".$_GET['course_ID']."'");
$formdata=array();
//db_insert('examination',$GLOBALS['rows']]])
$keys = array_keys($GLOBALS['rows'][0]);
$random = rand(1,100);
foreach ($keys as $value) {
    $formdata[$value]=$GLOBALS['rows'][0][$value].$random;
}
db_insert('examination',$formdata);
print_r($GLOBALS['rows']);
echo '\n';
print_r($formdata);
?>