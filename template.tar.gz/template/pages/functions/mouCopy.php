<?php   
require_once('../init.php');
require_once('../sessionInit.php');
//    db_select('faculty',$what,"where email='".$_SESSION['Email']."'");    
$what='*';
db_select('mou',$what,"where date='".$_GET['date']."'"." and topic='".$_GET['topic']."'");
$formdata=array();
//db_insert('examination',$GLOBALS['rows']]])
$keys = array_keys($GLOBALS['rows'][0]);
$random = rand(1,100);
foreach ($keys as $value) {
	if($value != 'date')
    $formdata[$value]=$random.$GLOBALS['rows'][0][$value];
}
db_insert('mou',$formdata);
print_r($GLOBALS['rows']);
echo '\n';
print_r($formdata);
?>