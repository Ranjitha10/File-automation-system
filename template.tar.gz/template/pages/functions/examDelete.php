<?php   
require_once('../init.php');
require_once('../sessionInit.php');
//    db_select('faculty',$what,"where email='".$_SESSION['Email']."'");    

db_delete('examination',"where date='".$_GET['date']."'"." and course_ID='".$_GET['course_ID']."'")

?>