<?php   
/* $formData = array(
					'Uploadedby' => $_SESSION['f_ID_no'],
                    'course_ID' => $_POST['course_ID'],
                    'f_ID_no' => $_POST['f_ID_no'],
                    'type' => $_POST['type'],
                    'date' =>$_POST['date'],
                    'dept' => $_POST['dept'],
                    'semester' => $_POST['semester'],
                    'year' => $_POST['year'], 
                  'programme'=> $_POST['programme']
          
                    );
                db_insert('student',$formData);
                */
    $path = "uploads/";
 //   echo $_FILES["file"]["tmp_name"];
    //echo '<br>';
    //echo $_FILES['file']['name'];
  move_uploaded_file($_FILES["file_link"]["tmp_name"], $path.$_FILES['file_link']['name'] );

?>
