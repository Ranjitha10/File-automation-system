<?php   
require_once('../init.php');
require_once('../sessionInit.php');
//    db_select('faculty',$what,"where email='".$_SESSION['Email']."'");    
$what='*';
db_select('publication',$what,"where ISSN='".$_GET['ISSN']."'");
$formdata=array();
//db_insert('examination',$GLOBALS['rows']]])
$keys = array_keys($GLOBALS['rows'][0]);
$random = rand(1,100);
foreach ($keys as $value) {
	if(!is_numeric($GLOBALS['rows'][0][$value]))
    $formdata[$value]=$random.'_COPY_'.$GLOBALS['rows'][0][$value];
}
db_insert('publication',$formdata);
print_r($GLOBALS['rows']);
echo '\n';
print_r($formdata);
?>