<?php   
if(isset($_POST['submit']))
{
	$Data = array(
                    'Uploadedby' => $_SESSION['Email']                 
                    );
                db_insert('Uploadedby',$Data);
}

?>
