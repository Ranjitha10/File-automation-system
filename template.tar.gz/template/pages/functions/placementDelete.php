<?php   
require_once('../init.php');
require_once('../sessionInit.php');
//    db_select('faculty',$what,"where email='".$_SESSION['Email']."'");    

db_delete('placement',"where USN='".$_GET['USN']."'"." and company='".$_GET['company']."'")

?>