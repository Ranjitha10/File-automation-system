<?php
/*
//Demo Login
if(isset($_POST['id']))
{
   $what = 'id';
   db_select('test',$what,"where id=".$_POST['id']);
   print_r($GLOBALS['rows']);
   if(sizeof($GLOBALS['rows'])>0)
   {
        echo 'valid';
   }
   else
   {
        echo 'invalid';
   }
}
*/

require_once('connect.php');
function db_insert($table_name, $form_data)
{
    // retrieve the keys of the array (column titles)
    $fields = array_keys($form_data);

    // build the query
    $sql = "INSERT INTO ".$table_name."
    (`".implode('`,`', $fields)."`)
    VALUES('".implode("','", $form_data)."')";
	//echo $sql;
    if (mysqli_query($GLOBALS['con'], $sql)) {
    //echo "New record created successfully";
	} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS['con']);
	}
    // run and return the query result resource
}
/*
dbRowInsert('my_table', $form_data);
$form_data = array(
    'first_name' => $first_name,
    'last_name' => $last_name,
    'email' => $email,
    'address1' => $address1,
    'address2' => $address2,
    'address3' => $address3,
    'postcode' => $postcode,
    'tel' => $tel,
    'mobile' => $mobile,
    'website' => $website,
    'contact_method' => $contact_method,
    'subject' => $subject,
    'message' => $message,
    'how_you_found_us' => $how_you_found_us,
    'time' => time()
);
*/

// the where clause is left optional incase the user wants to delete every row!
function db_delete($table_name, $where_clause='')
{
    // check for optional where clause
    $whereSQL = '';
    if(!empty($where_clause))
    {
        // check to see if the 'where' keyword exists
        if(substr(strtoupper(trim($where_clause)), 0, 5) != 'WHERE')
        {
            // not found, add keyword
            $whereSQL = " WHERE ".$where_clause;
        } else
        {
            $whereSQL = " ".trim($where_clause);
        }
    }
    // build the query
    $sql = "DELETE FROM ".$table_name.$whereSQL;
//	echo $sql;
    // run and return the query result resource -> upddated to execute
    //return mysql_query($sql);
    
    if (mysqli_query($GLOBALS['con'], $sql)) {
    	//echo "New record created successfully";
	}
	 else {
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}




// again where clause is left optional
function db_update($table_name, $form_data, $where_clause='')
{
    // check for optional where clause
    $whereSQL = '';
    if(!empty($where_clause))
    {
        // check to see if the 'where' keyword exists
        if(substr(strtoupper(trim($where_clause)), 0, 5) != 'WHERE')
        {
            // not found, add key word
            $whereSQL = " WHERE ".$where_clause;
        } else
        {
            $whereSQL = " ".trim($where_clause);
        }
    }
    // start the actual SQL statement
    $sql = "UPDATE ".$table_name." SET ";

    // loop and build the column /
    $sets = array();
    foreach($form_data as $column => $value)
    {
         $sets[] = "`".$column."` = '".$value."'";
    }
    $sql .= implode(', ', $sets);

    // append the where statement
    $sql .= $whereSQL;
//	echo $sql;
    // run and return the query result
   // return mysql_query($sql);
    if (mysqli_query($GLOBALS['con'], $sql)) {
    	//echo "New record created successfully";
	}
	 else {
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}



function db_select($table_name,$what, $where_clause='')
{
    // check for optional where clause
    $whereSQL = '';
    if(!empty($where_clause))
    {
        // check to see if the 'where' keyword exists
        if(substr(strtoupper(trim($where_clause)), 0, 5) != 'WHERE')
        {
            // not found, add keyword
            $whereSQL = " WHERE ".$where_clause;
        } else
        {
            $whereSQL = " ".trim($where_clause);
        }
    }
    // build the query
    $sql = "SELECT ".$what." FROM ".$table_name.$whereSQL;
    $result = mysqli_query($GLOBALS['con'], $sql);
    $GLOBALS['rows']=array();
  //  echo $sql;
    $count=0;
    if (mysqli_num_rows($result) > 0) {
    // output data of each row
	
    while($GLOBALS['rows'][$count] = mysqli_fetch_assoc($result)) {
		//print_r($GLOBALS['rows'][$count]);
       // echo "id: " . $GLOBALS['rows'][$count]["id"]. " - Name: " . $GLOBALS['rows'][$count]["user"]."<br>";
        $count++;
    }
} else {
  //  echo "0 results";
}
   // echo $sql;
    // run and return the query result resource -> upddated to execute
    //return mysql_query($sql);
   /* 
    if (mysqli_query($GLOBALS['con'], $sql)) {
    	//echo "New record created successfully";
	}
	 else {
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}*/
}

?>
