
<?php
require_once('connect.php');

require_once('dbTransactions.php');
if(isset($_POST['Login']))
{
	 $what = '*';
   db_select("`6`",$what,"where usn='".$_POST['usn']."' and pass='".$_POST['pass']."'");
   if(sizeof($GLOBALS['rows'])>0)
   {
        echo 'logged in';            
              //      $_SESSION['usn']=$_POST['usn'];
			
echo '			<script>
			
			 setTimeout(function () { document.getElementById("login").style.visibility = "hidden";
			 
			 var x =10;}, 200);
			 </script>';
			 		
echo '<script>
function loadXMLDoc()
{
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
	var x = xmlhttp.responseText;
	json=JSON.parse(x);
   // document.getElementById("myDiv").innerHTML=x;
//       console.log(obj);

console.log(json.length);
count =0; 
var comm,all;
all="<table><tr><td>Name</td><td>Comment</td></tr>";
console.log(json);
for(i =1 ; i<json.length;i++)
	{ 
		comm="<tr><td>"+json[count].name+"</td><td>"+json[count].comment+"</td></tr>";	
		all =  all + comm;
		console.log(json[count].name);
		count++;
	}
	all+="</table>";
	
	setTimeout(function () {document.getElementById("display").innerHTML=all;
			 
			 var x =10;}, 300);
	console.log(all);
//document.getElementById("display").innerHTML="<table>";

    }
  }
xmlhttp.open("GET","comm.php",true);
xmlhttp.send();
}
setTimeout(loadXMLDoc(),3000);
</script>
';	
   }
   else
   {
        echo 'login fail';
   }
}

if(isset($_POST['Submit']))
{
	$form_data = array(
    'name' => $_POST['cname'],
    'comment' => $_POST['comment']
    );
    db_insert("comments", $form_data);
}
?>
<html>
<head>
	<style>
	table {
   
    width: 100%;
}
	</style>
</head>
<body>
<div id="display">
<div id="login">
	<form method="POST">
	Name<input id="usn" type="text" name="usn"><br>
	</input>
	Password<input id="pass" type="text" name="pass"><br>
	</input>
	<input type="submit" value="Login" name="Login"><br>
	</form>

<form method="POST"><br>
name	<input id="cname" name="cname"><br>
comment: <input id="comment" name="comment" type="textbox" size="100"><br>
	<input type="submit" value="Submit" name="Submit">
</form>
</div>

</div>
<script>

</script>

</body>
</html>
