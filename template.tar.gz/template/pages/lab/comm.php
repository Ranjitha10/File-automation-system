<?php
require_once('connect.php');

require_once('dbTransactions.php');
?>

<?php
$what = '*';
   db_select("comments",$what);
//   print_r($GLOBALS['rows']);
echo json_encode($GLOBALS['rows']);
   ?>
