   <?php

   require_once('core/session.php');
    require_once('core/sessionCheck.php');
    ?>
